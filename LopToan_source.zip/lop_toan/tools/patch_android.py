"""Chỉnh khung Android do `flutter create` sinh ra:
- ký APK bằng khóa cố định trong keys/ (để cài bản mới đè bản cũ mà KHÔNG mất dữ liệu)
- đặt tên app, quyền mở ứng dụng gọi điện / SMS / Zalo
- thay icon app
- nâng phiên bản Kotlin nếu quá cũ
"""
import pathlib
import re
import shutil
import sys

root = pathlib.Path(__file__).resolve().parent.parent
android = root / "android"
app = android / "app"

# ---------------------------------------------------------------- ký APK
kts = app / "build.gradle.kts"
groovy = app / "build.gradle"
if kts.exists():
    gradle = kts
    block = '''
    signingConfigs {
        getByName("debug") {
            storeFile = file("../../keys/debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
'''
elif groovy.exists():
    gradle = groovy
    block = '''
    signingConfigs {
        debug {
            storeFile file("../../keys/debug.keystore")
            storePassword "android"
            keyAlias "androiddebugkey"
            keyPassword "android"
        }
    }
'''
else:
    sys.exit("Không tìm thấy android/app/build.gradle(.kts)")

text = gradle.read_text(encoding="utf-8")
if "keys/debug.keystore" not in text:
    text, n = re.subn(r"^android\s*\{\s*$", "android {" + block, text, count=1, flags=re.M)
    if n != 1:
        sys.exit("Không chèn được signingConfigs vào " + gradle.name)
if "signingConfigs.getByName(\"debug\")" not in text and "signingConfigs.debug" not in text:
    print("CẢNH BÁO: buildTypes.release không dùng khóa debug — kiểm tra lại", gradle.name)
gradle.write_text(text, encoding="utf-8")
print("Đã cấu hình khóa ký:", gradle.name)

# ------------------------------------------------------------- Manifest
manifest = app / "src" / "main" / "AndroidManifest.xml"
m = manifest.read_text(encoding="utf-8")
m = re.sub(r'android:label="[^"]*"', 'android:label="Lớp Toán"', m, count=1)
if "android.intent.action.DIAL" not in m:
    queries = '''
    <queries>
        <intent>
            <action android:name="android.intent.action.DIAL" />
            <data android:scheme="tel" />
        </intent>
        <intent>
            <action android:name="android.intent.action.SENDTO" />
            <data android:scheme="sms" />
        </intent>
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:scheme="https" />
        </intent>
    </queries>
'''
    m = m.replace("</manifest>", queries + "</manifest>")
manifest.write_text(m, encoding="utf-8")
print("Đã sửa AndroidManifest.xml")

# ----------------------------------------------------------------- Icon
icons = root / "branding" / "icons"
res = app / "src" / "main" / "res"
for d in icons.glob("mipmap-*"):
    target = res / d.name
    target.mkdir(parents=True, exist_ok=True)
    shutil.copy(d / "ic_launcher.png", target / "ic_launcher.png")
print("Đã thay icon")

# --------------------------------------------------------------- Kotlin
for name in ("settings.gradle.kts", "settings.gradle"):
    f = android / name
    if not f.exists():
        continue
    s = f.read_text(encoding="utf-8")
    s2 = re.sub(
        r'(id\(?\s*"org\.jetbrains\.kotlin\.android"\s*\)?\s+version\s+")1\.[0-9.]+(")',
        r"\g<1>2.1.0\g<2>",
        s,
    )
    if s2 != s:
        f.write_text(s2, encoding="utf-8")
        print("Đã nâng Kotlin lên 2.1.0 trong", name)
