import 'package:flutter/material.dart';

import '../db.dart';
import '../utils.dart';
import '../widgets.dart';

class FeesScreen extends StatefulWidget {
  const FeesScreen({super.key});
  @override
  State<FeesScreen> createState() => _FeesScreenState();
}

class _FeesScreenState extends State<FeesScreen> with AutoReload<FeesScreen> {
  DateTime month = DateTime(DateTime.now().year, DateTime.now().month, 1);
  List<SchoolClass> classes = [];
  List<Student> students = [];
  Map<int, Fee> fees = {};
  int? classFilter;
  bool onlyUnpaid = false;
  bool loading = true;

  String get monthKey => ym(month);

  @override
  Future<void> reload() async {
    final db = AppDb.instance;
    final c = await db.getClasses();
    final s = await db.getStudents();
    final f = await db.getFees(monthKey);
    if (!mounted) return;
    setState(() {
      classes = c;
      students = s;
      fees = f;
      if (classFilter != null && !c.any((x) => x.id == classFilter)) classFilter = null;
      loading = false;
    });
  }

  void _shift(int delta) {
    setState(() => month = DateTime(month.year, month.month + delta, 1));
    reload();
  }

  int _amountFor(Student s) {
    final f = fees[s.id];
    if (f != null && f.amount > 0) return f.amount;
    final c = classes.where((x) => x.id == s.classId);
    return c.isEmpty ? 0 : c.first.fee;
  }

  Future<void> _toggle(Student s) async {
    final paid = fees[s.id]?.paid ?? false;
    await AppDb.instance.setFee(s.id!, monthKey, paid: !paid, amount: _amountFor(s));
  }

  Future<void> _editAmount(Student s) async {
    final r = await textInputDialog(context, 'Học phí ${monthLabel(monthKey)} – ${s.name}',
        initial: '${_amountFor(s)}', hint: 'Số tiền (đ)', keyboard: TextInputType.number);
    if (r == null) return;
    await AppDb.instance.setFee(s.id!, monthKey, paid: fees[s.id]?.paid ?? false, amount: parseMoney(r));
  }

  @override
  Widget build(BuildContext context) {
    final shown = students.where((s) {
      if (classFilter != null && s.classId != classFilter) return false;
      if (onlyUnpaid && (fees[s.id]?.paid ?? false)) return false;
      return true;
    }).toList();
    final scope = students.where((s) => classFilter == null || s.classId == classFilter).toList();
    var paidN = 0, paidSum = 0, unpaidN = 0, unpaidSum = 0;
    for (final s in scope) {
      if (fees[s.id]?.paid ?? false) {
        paidN++;
        paidSum += fees[s.id]!.amount;
      } else {
        unpaidN++;
        unpaidSum += _amountFor(s);
      }
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Học phí')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 32),
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [kNavy, kNavyDark]),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(children: [
                    Row(children: [
                      IconButton(
                        onPressed: () => _shift(-1),
                        icon: const Icon(Icons.chevron_left, color: Colors.white),
                      ),
                      Expanded(
                        child: Text(monthLabel(monthKey),
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
                      ),
                      IconButton(
                        onPressed: () => _shift(1),
                        icon: const Icon(Icons.chevron_right, color: Colors.white),
                      ),
                    ]),
                    const SizedBox(height: 8),
                    Row(children: [
                      _sum('Đã thu', '$paidN em', fmtMoney(paidSum), const Color(0xFF86EFAC)),
                      Container(width: 1, height: 44, color: Colors.white24),
                      _sum('Chưa thu', '$unpaidN em', fmtMoney(unpaidSum), const Color(0xFFFCA5A5)),
                    ]),
                  ]),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  height: 42,
                  child: ListView(scrollDirection: Axis.horizontal, children: [
                    Padding(
                      padding: const EdgeInsets.only(right: 6),
                      child: FilterChip(
                        label: const Text('Chỉ em chưa đóng'),
                        selected: onlyUnpaid,
                        onSelected: (v) => setState(() => onlyUnpaid = v),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 6),
                      child: ChoiceChip(
                        label: const Text('Tất cả lớp'),
                        selected: classFilter == null,
                        onSelected: (_) => setState(() => classFilter = null),
                      ),
                    ),
                    for (final c in classes)
                      Padding(
                        padding: const EdgeInsets.only(right: 6),
                        child: ChoiceChip(
                          label: Text(c.name),
                          selected: classFilter == c.id,
                          onSelected: (_) => setState(() => classFilter = c.id),
                        ),
                      ),
                  ]),
                ),
                const SizedBox(height: 8),
                if (shown.isEmpty)
                  EmptyState(
                    icon: onlyUnpaid ? Icons.celebration_outlined : Icons.people_outline,
                    title: onlyUnpaid ? 'Tất cả đã đóng học phí!' : 'Chưa có học sinh',
                  ),
                for (final c in classes)
                  if (shown.any((s) => s.classId == c.id)) ...[
                    Padding(
                      padding: const EdgeInsets.fromLTRB(2, 10, 2, 6),
                      child: Row(children: [
                        Container(
                            width: 10, height: 10, decoration: BoxDecoration(color: classColor(c.color), shape: BoxShape.circle)),
                        const SizedBox(width: 8),
                        Text(c.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                        const Spacer(),
                        Text(c.fee > 0 ? '${fmtMoney(c.fee)}/tháng' : 'Chưa đặt học phí',
                            style: const TextStyle(color: kMuted, fontSize: 12.5)),
                      ]),
                    ),
                    for (final s in shown.where((s) => s.classId == c.id)) _row(s),
                  ],
                const SizedBox(height: 6),
                const Text('Chạm để đánh dấu đã đóng / chưa đóng · Nhấn giữ để sửa số tiền',
                    textAlign: TextAlign.center, style: TextStyle(color: kMuted, fontSize: 12)),
              ],
            ),
    );
  }

  Widget _sum(String label, String n, String money, Color c) {
    return Expanded(
      child: Column(children: [
        Text(label, style: TextStyle(color: Colors.white.withValues(alpha: 0.75), fontSize: 12.5)),
        const SizedBox(height: 2),
        Text(money, style: TextStyle(color: c, fontSize: 17, fontWeight: FontWeight.w800)),
        Text(n, style: TextStyle(color: Colors.white.withValues(alpha: 0.75), fontSize: 12)),
      ]),
    );
  }

  Widget _row(Student s) {
    final f = fees[s.id];
    final paid = f?.paid ?? false;
    return PaperCard(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.fromLTRB(6, 4, 8, 4),
      color: paid ? const Color(0xFFF0FDF4) : Colors.white,
      onTap: () => _toggle(s),
      onLongPress: () => _editAmount(s),
      child: Row(children: [
        Checkbox(value: paid, activeColor: kGreen, onChanged: (_) => _toggle(s)),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(s.name, style: const TextStyle(fontWeight: FontWeight.w700)),
            Text(
              paid && f!.paidDate.isNotEmpty ? 'Đã đóng ngày ${dmy(f.paidDate)}' : 'Chưa đóng',
              style: TextStyle(fontSize: 12, color: paid ? kGreen : kRed),
            ),
          ]),
        ),
        Text(fmtMoney(_amountFor(s)), style: const TextStyle(fontWeight: FontWeight.w700)),
        if (!paid && s.parentPhone.isNotEmpty)
          IconButton(
            tooltip: 'Nhắn nhắc học phí',
            icon: const Icon(Icons.sms_outlined, color: kNavy, size: 20),
            onPressed: () => sendSms(
              context,
              s.parentPhone,
              'Thầy xin phép nhắc phụ huynh em ${s.name}: học phí ${monthLabel(monthKey).toLowerCase()} là ${fmtMoney(_amountFor(s))}. Cảm ơn phụ huynh!',
            ),
          ),
      ]),
    );
  }
}
